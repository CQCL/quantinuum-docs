// Copyright 2020-2024 Quantinuum
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


int PFU = 0;


void init() {
    // to initialise the Wasm sandbox environment   
}


void set_pfu_value(int syn) {
    switch(syn){
        case 1:
            PFU = 4; // 000000100
        case 2:
            PFU = 128; // 010000000
        case 4:
            PFU = 1; // 000000001
        case 8:
            PFU = 64; // 001000000
        case 3:
            PFU = 32; // 000100000
        case 6:
            PFU = 16; // 000010000
        case 12:
            PFU = 8; // 000001000
        case 5:
            PFU = 48; // 000110000
        case 10:
            PFU = 24; // 000011000
        case 9:
            PFU = 68; // 001000100
        case 7:
            PFU = 33; // 000100001
        case 11:
            PFU = 96; // 001100000
        case 13:
            PFU = 12; // 000001100
        case 14:
            PFU = 136; // 010001000
        case 15:
            PFU = 40; // 000101000
    }
}


void update_pfu(int syn) {
    int pfu_temp = PFU;
    set_pfu_value(syn);
    PFU = pfu_temp ^ PFU;
}


int get_pfu() {
    return PFU;
}


void reset_pfu() {
    PFU = 0; // 000000000
}

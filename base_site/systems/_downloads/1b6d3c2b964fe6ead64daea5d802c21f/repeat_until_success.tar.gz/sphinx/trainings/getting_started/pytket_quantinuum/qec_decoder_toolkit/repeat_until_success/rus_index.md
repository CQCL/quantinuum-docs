
# Repeat Until Success

Conditionally adding quantum operations to a circuit based on equality comparisons with an in-memory Wasm variable.

There are two folders for (rust and c) compilation to Wasm.

```{table}
:name: rus_download

| File | Download |
|------|-------------|
| Repeat Until Success Project | {download}`Download <../repeat_until_success.tar.gz>`|
```

## C Project

### C Source

```{literalinclude} c/src/lib.c
:caption: src/lib.c
```

### CMake Files

```{literalinclude} c/CMakeLists.txt
:caption: CMakeLists.txt
```

```{literalinclude} c/wasm-toolchain.cmake
:caption: wasm-toolchain.cmake
```

### C GTests

```{literalinclude} c/tests/test_lib.cc
:caption: tests/test_lib.cc
```

```{literalinclude} c/tests/CMakeLists.txt
:caption: tests/CMakeLists.txt
```

## Rust Project

### Rust Source and Tests
```{literalinclude} rust/src/lib.rs
:caption: src/lib.rs
```

### Cargo TOML File

```{literalinclude} rust/Cargo.toml
:caption: Cargo.toml
```


# Repetition Code

$[[3, 1, 2]]$ code to encode 1 logical qubit into 3 physical qubits with code-distance 2.

There are two folders for (rust and c) compilation to Wasm.

```{table}
:name: repetition_code_download

| File | Download |
|------|----------|
| Repetition Code Project | {download}`Download <../repetition_code.tar.gz>` |
```

## C Project

### C Source

```{literalinclude} c/src/lib.c
:caption: src/lib.c
```

### CMake Files

```{literalinclude} c/CMakeLists.txt
:caption: CMakeLists.txt
```

```{literalinclude} c/wasm-toolchain.cmake
:caption: wasm-toolchain.cmake
```

### C GTests

```{literalinclude} c/tests/test_lib.cc
:caption: tests/test_lib.cc
```

```{literalinclude} c/tests/CMakeLists.txt
:caption: tests/CMakeLists.txt
```

## Rust Project

### Rust Source and Tests
```{literalinclude} rust/src/lib.rs
:caption: src/lib.rs
```

### Cargo TOML File

```{literalinclude} rust/Cargo.toml
:caption: Cargo.toml
```
